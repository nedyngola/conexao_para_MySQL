package conexao;

import connect.connectFactory;
import telabd.formulario;

public class Main {
    public static void main(String[] args) {
        if (connectFactory.getConnection() != null) {
            System.out.println("Conectado com sucesso!");
        } else {
            System.out.println("Não foi possível estabelecer a conexão.");
        }

        formulario formulario = new formulario();
        formulario.setVisible(true);
    }
}


