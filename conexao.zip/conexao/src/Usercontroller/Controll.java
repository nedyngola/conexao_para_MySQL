package Usercontroller;

import Classe.Usuario;
import connect.connectFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Controll {

    public void Registrar(Usuario u) {
        String sql = "INSERT INTO usuario2 (nome, telefone, email) VALUES (?, ?, ?)";

        try (Connection conn = connectFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, u.getNome());
            ps.setString(2, u.getTelefone());
            ps.setString(3, u.getEmail());
            ps.execute();
            System.out.println("Registro inserido com sucesso!");

        } catch (SQLException e) {
        }
    }
}
