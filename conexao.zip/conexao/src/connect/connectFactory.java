
/* 
package connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class connectFactory {
    
  





    private static Connection c= null;
    private static final String url = "jdbc:mysql://127.0.0.1:3306/conexaomysql";
    private static final String user = "root";
    private static final String password = "";

    // Método para obter a conexão com o banco de dados
    public static Connection getConnection() {
        // Configurações do banco de dados

        try {
            if (c == null) {
                c = DriverManager.getConnection(url, user, password);
                     return c ;
            } else {
                return c;
            }

        } catch (SQLException e.) {
            e.printStackTrace();
            return null;
       }

    }   
}
 */

package connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class connectFactory {

    private static Connection c = null;
    private static final String url = "jdbc:mysql://127.0.0.1:3306/conexaomysql";
    private static final String user = "root";
    private static final String password = "";

    // Método para obter a conexão com o banco de dados
    public static Connection getConnection() {
        try {
            if (c == null || c.isClosed()) {
                c = DriverManager.getConnection(url, user, password);
            }
            return c;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
    
