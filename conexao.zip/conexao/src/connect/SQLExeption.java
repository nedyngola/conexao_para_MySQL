package connect;

class SQLExeption {
    
}
